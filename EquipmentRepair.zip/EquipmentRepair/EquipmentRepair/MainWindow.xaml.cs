﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EquipmentRepair
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Utilities _utilities = new Utilities();
        private EquipmentRepairEntities _db = new EquipmentRepairEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SignInButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginEnter.Text;
            string password = PasswordEnter.Text;

            int role = _utilities.Authorization(login, password);

            if ( role == 0)
            {
                MessageBox.Show("Возникли проблемы с проверкой логина или пароля!", "Ошибка!");
            }
            else if ( role == 1 )
            {
                var client = _db.Client.Where(c => c.Surename == login & c.Phone == password).First();
                new ClientOrderWindow(client).Show();
                this.Close();
            }
            else if ( role == 2 )
            {
                var employee = _db.Employee.Where(c => c.Surename == login & c.Phone == password).First();
                new EmpoueeOrderWindow(employee).Show();
                this.Close();
            }
            else if( role == 3 )
            {
                var admin = _db.Employee.Where(c => c.Surename == login & c.Phone == password).First();
                new AdminOrderWindow(admin).Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Возникли проблемы с проверкой логина или пароля!", "Ошибка!");
            }
        }
    }
}
