﻿using System.Data.Entity;
using System.Linq;
using System.Net.NetworkInformation;

namespace EquipmentRepair
{
    internal class Utilities
    {
        private EquipmentRepairEntities _db = new EquipmentRepairEntities();
        public int Authorization(string login, string password)
        {
            if(login.Length <= 1)
                return 0;
            if(password.Length <= 1)
                return 0;

            var client = _db.Client.Where(c => c.Surename == login && c.Phone == password).FirstOrDefault();

            var employee = _db.Employee.Where(e => e.Surename == login && e.Phone == password).FirstOrDefault();
            
            if (client == null && employee == null)
                return -1;

            if (client != null)
                return 1;

            if(employee != null && !employee.IsAdmin)
                return 2;

            if(employee != null && employee.IsAdmin)
                return 3;

            return 0;

        }
    }
}
